
/*  发送修改的消息 */
function modifySend(data) {

	data = json2one(data,{ssid: localStorage.ssid});
	$.getJSON("http://127.0.0.1/todo/index.php/Api/Modify/one", data, function (json) {
		alert('return');
		return true;
	});
}

/*监听右键菜单*/
function add2today(info, tab) { 
	addtodo({floder:'today',content:info.selectionText});
}
function add2tomorrow(info, tab) { 
	addtodo({floder:'tomorrow',content:info.selectionText});
}
function add2week(info, tab) { 
	addtodo({floder:'week',content:info.selectionText});
}
function add2later(info, tab) { 
	addtodo({floder:'later',content:info.selectionText});
}
function add2note(info, tab) {
	addtodo({floder:'note',content:info.selectionText});
}

/*添加到目录和Ajax操作*/
function addtodo(data){
	data = json2one(data,{ssid:localStorage.ssid});
	$.getJSON("http://127.0.0.1/todo/index.php/Api/Modify/add", data, function (json) {
		
		if(data.istmpl){
		todo_html = '<div class="todo" draggable="true"><span class="tag" id="tag_0" ></span><span class="content" >'
					+ data.content + '</span><span class="checked"></span><div class="modify" ><textarea class="textarea" maxlength="84" rows="4" data-id="'+json.id+'">'
					+ data.content + '</textarea><div class="tool"><span class="tagslist">'//下面是所有的标签
					+ eval_tags(0,JSON.parse(localStorage.tags)) + '</span>'
					+ '<span class="addnote"></span><span class="remind" data-id="'+json.id+'"></span>'
					+ '</div></div</div>';
			$('#' + data.folder + '>.todolist').append(todo_html);
		
		}
		
		return json;
	});
}


function modifytag(data){

	data ={ssid:localStorage.ssid,tags:data};
	$.getJSON("http://127.0.0.1/todo/index.php/Api/Modify/modifyTag", data, function (json) {
		return json;
	});

}
/*合并两个json*/
function json2one(des, src, override) {
	if (src instanceof Array) {
		for (var i = 0, len = src.length; i < len; i++)
			json2one(des, src[i], override);
	}
	for (var i in src) {
		if (override || !(i in des)) {
			des[i] = src[i];
		}
	}
	return des;
}
