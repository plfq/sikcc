/**/


$(document).ready(function() {
	$("#me").click(function() {
		$.getJSON("http://127.0.0.1/At/index", function(data) {

		});
	});
});